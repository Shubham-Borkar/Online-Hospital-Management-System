function ResourceUpdate() {
    return ( <>Resource Update</> );
}

export default ResourceUpdate;