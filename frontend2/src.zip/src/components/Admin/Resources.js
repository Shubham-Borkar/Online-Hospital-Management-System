import '../../../node_modules/bootstrap/dist/css/bootstrap.css'
import '../../mystyle.css'
import Header from "../Layout/Header";
import Footer from '../Layout/Footer';
import { useEffect, useState } from 'react';
import axios from 'axios';
import { BaseApi } from '../api/BaseApi';
import { toast } from 'react-toastify';


function Resources() {
  const [res, setRes] = useState([]);

  useEffect(() => {
    debugger
    console.log("on pid update");
    select();
  }, [])

  const select = () => {
    debugger;
    var tokenn=sessionStorage.getItem("token")
    const url = `resource`;
    debugger;
    axios.get(`${BaseApi.server_url}${url}`,
    { headers: {"Authorization" : `Bearer ${tokenn}`}})
      .then(res => {
        debugger;
        setRes(res.data);
        debugger;
        console.log(res.data)
      })
      .catch(()=>toast.error('Error Getting Resources'))
  }

  const update=(e)=>{
    debugger
    console.log(e.target.value)
    let avail = e.target.value

  }

  const bed = 350;

  return (<>
   {/* 
   {
          res.map((s) => {
            let per=((s.availableCount)/s.totalCount)*500;
            return <>
            <h2>{s.resource}</h2>
            <h3>{per}</h3>
            </>
})
 } 
 */}
    <Header />
    <div> <br /><br /><br /><br />
      <center>

        {
          res.map((s) => {
            var per=((s.availableCount)/s.totalCount)*500;
            var sty="progress-bar bg-danger";
            if(per>150)
            sty="progress-bar bg-warning"
            if(per>300)
            sty="progress-bar bg-info"
            if(per>400)
            sty="progress-bar bg-success";
            

            
            
            return (<>

              <h2 onClick={update} value={s}>
                {s.resource} ({s.availableCount}/{s.totalCount})</h2>
              <div className="progress" style={{ width: "500px", height: "50px" }}>
                <div
                  className={sty}
                  role="progressbar"
                  style={{ width: per }}>
                  <span className="sr-only">{per/5}Percent Available (success)</span>
                </div>
              </div>

            </>);
          })
        }
       
      </center>
    </div>

  </>)
}

export default Resources;