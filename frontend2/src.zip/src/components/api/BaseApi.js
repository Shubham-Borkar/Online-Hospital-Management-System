export const BaseApi = {

    base_url: "http://localhost:3000/",
    
    server_url: "https://127.0.0.1:8181/"
    
}
