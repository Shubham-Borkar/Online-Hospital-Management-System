function InvalidPage() {
    return (<>
                <h2>Error: 404</h2>
                <h3>Page not Found !!</h3>
                <hr/>
            </>);
}

export default InvalidPage;